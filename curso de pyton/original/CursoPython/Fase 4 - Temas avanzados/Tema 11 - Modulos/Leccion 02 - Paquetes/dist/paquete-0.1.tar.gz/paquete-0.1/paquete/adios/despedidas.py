# -*- coding: utf-8 -*-
"""
Created on Fri Jan 22 09:07:26 2021

@author: User
"""

# este es un modulo con funciones que despiden

def despedirse():
    print("adios  me estoy despidiendo desde la funcion despedirse del modulo despedidas")
    
class Despedida():
    def __init__(self):
        print("adios  me estoy despidiendo desde el init de la clase Despedida")
    