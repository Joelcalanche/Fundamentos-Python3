# -*- coding: utf-8 -*-
"""
Created on Fri Jan 22 09:07:26 2021

@author: User
"""

# este es un modulo con funciones que saludan

def saludar():
    print("hola te estoy saludando desde la funcion saludar del modulo saludos")
    
class Saludo():
    def __init__(self):
        print("hola te estoy saludando desde el init de la clase saludo")
    